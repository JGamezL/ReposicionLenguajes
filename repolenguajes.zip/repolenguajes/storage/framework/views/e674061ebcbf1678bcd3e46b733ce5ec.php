<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Producto</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="bg-gray-200 p-8">
    <div class="container mx-auto">
        <h1 class="text-2xl font-bold mb-4">Agregar Producto</h1>

        <form action="<?php echo e(route('productos.store')); ?>" method="post" class="bg-white p-6 rounded-md shadow-md">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label for="descripcion" class="block text-gray-700 font-semibold mb-2">Descripción:</label>
                <input type="text" name="descripcion" id="descripcion" class="w-full border p-2 rounded-md">
            </div>

            <div class="mb-4">
                <label for="precio" class="block text-gray-700 font-semibold mb-2">Precio:</label>
                <input type="text" name="precio" id="precio" class="w-full border p-2 rounded-md">
            </div>

            <div class="mb-4">
                <label for="stock" class="block text-gray-700 font-semibold mb-2">Stock:</label>
                <input type="text" name="stock" id="stock" class="w-full border p-2 rounded-md">
            </div>

            <div class="mb-4">
                <label for="pagaIsv" class="block text-gray-700 font-semibold mb-2">Paga ISV:</label>
                <input type="checkbox" name="pagaIsv" id="pagaIsv" value="1">
            </div>

            <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-700">Agregar Producto</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Joel\Documents\Código\PHP\repolenguajes\resources\views/productos/create.blade.php ENDPATH**/ ?>