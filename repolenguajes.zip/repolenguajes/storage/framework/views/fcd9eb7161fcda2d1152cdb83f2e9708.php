<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empleados</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="bg-gray-200 p-8">
    <div class="container mx-auto">
    <div class="flex justify-between items-center mb-4">
            <h1 class="text-2xl font-bold">Empleados</h1>
            <a href="<?php echo e(route('empleados.create')); ?>" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-700">Agregar Empleado</a>
        </div>


        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white p-4 mb-4 rounded-md shadow-md">
                <p class="text-lg font-semibold"><?php echo e($empleado->nombre); ?> <?php echo e($empleado->apellido); ?></p>
                <p>Fecha de Ingreso: <?php echo e($empleado->fechaIngreso); ?></p>
                <p>Salario: $<?php echo e($empleado->salario); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Joel\Documents\Código\PHP\repolenguajes\resources\views/empleado/index.blade.php ENDPATH**/ ?>