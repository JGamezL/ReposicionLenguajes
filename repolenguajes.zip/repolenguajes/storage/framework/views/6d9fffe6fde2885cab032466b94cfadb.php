<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Empleado</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="bg-gray-200 p-8">
    <div class="container mx-auto">
        <h1 class="text-2xl font-bold mb-4">Agregar Empleado</h1>

        <form action="<?php echo e(route('empleados.store')); ?>" method="post" class="bg-white p-6 rounded-md shadow-md">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label for="nombre" class="block text-gray-700 font-semibold mb-2">Nombre:</label>
                <input type="text" name="nombre" id="nombre" class="w-full border p-2 rounded-md">
            </div>

            <div class="mb-4">
                <label for="apellido" class="block text-gray-700 font-semibold mb-2">Apellido:</label>
                <input type="text" name="apellido" id="apellido" class="w-full border p-2 rounded-md">
            </div>

            <div class="mb-4">
                <label for="fechaIngreso" class="block text-gray-700 font-semibold mb-2">Fecha de Ingreso:</label>
                <input type="date" name="fechaIngreso" id="fechaIngreso" class="w-full border p-2 rounded-md">
            </div>

            <div class="mb-4">
                <label for="salario" class="block text-gray-700 font-semibold mb-2">Salario:</label>
                <input type="text" name="salario" id="salario" class="w-full border p-2 rounded-md">
            </div>

            <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-700">Agregar Empleado</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Joel\Documents\Código\PHP\repolenguajes\resources\views/empleado/create.blade.php ENDPATH**/ ?>