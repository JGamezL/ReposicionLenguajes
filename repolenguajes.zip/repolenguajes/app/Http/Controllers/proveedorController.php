<?php

namespace App\Http\Controllers;

use App\Models\Proveedor;
use Illuminate\Http\Request;

class proveedorController extends Controller
{
    //
    public function index(){
        $proveedores = Proveedor::all();
        return view('proveedor.index', compact('proveedores'));
    }

    public function create(){
        return view('proveedor.create');
    }

    public function store(Request $request){
        $proveedor = new Proveedor();
        $proveedor->nombre = $request->nombre;
        $proveedor->fechaRegistro = $request->fechaRegistro;
        $proveedor->telefono = $request->telefono;
        $proveedor->correo = $request->correo;
        $proveedor->save();
        return redirect()->route('proveedor.index');
    }
    

}
