<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Productos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="bg-gray-200 p-8">
    <div class="container mx-auto">
        <div class="flex justify-between items-center mb-4">
            <h1 class="text-2xl font-bold">Productos</h1>
            <a href="{{ route('productos.create') }}" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-700">Agregar Producto</a>
        </div>

        @foreach($productos as $producto)
            <div class="bg-white p-4 mb-4 rounded-md shadow-md">
                <p class="text-lg font-semibold">{{ $producto->descripcion }}</p>
                <p>Precio: ${{ $producto->precio }}</p>
                <p>Stock: {{ $producto->stock }}</p>
                <p>Paga ISV: {{ $producto->pagaIsv ? 'Sí' : 'No' }}</p>
            </div>
        @endforeach
    </div>
</body>
</html>
