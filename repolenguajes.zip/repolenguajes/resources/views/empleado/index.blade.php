<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empleados</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="bg-gray-200 p-8">
    <div class="container mx-auto">
    <div class="flex justify-between items-center mb-4">
            <h1 class="text-2xl font-bold">Empleados</h1>
            <a href="{{ route('empleados.create') }}" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-700">Agregar Empleado</a>
        </div>


        @foreach($empleados as $empleado)
            <div class="bg-white p-4 mb-4 rounded-md shadow-md">
                <p class="text-lg font-semibold">{{ $empleado->nombre }} {{ $empleado->apellido }}</p>
                <p>Fecha de Ingreso: {{ $empleado->fechaIngreso }}</p>
                <p>Salario: ${{ $empleado->salario }}</p>
            </div>
        @endforeach
    </div>
</body>
</html>
