<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\productoController;
use App\Http\Controllers\empleadoController;
use App\Http\Controllers\proveedorController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//Para productos
Route::get('/productos', [productoController::class, 'index'])->name('productos.index');
Route::get('/productos/create', [productoController::class, 'create'])->name('productos.create');
Route::post('/productos', [productoController::class, 'store'])->name('productos.store');
//Para empleados
Route::get('/empleados', [empleadoController::class, 'index'])->name('empleados.index');
Route::get('/empleados/create', [empleadoController::class, 'create'])->name('empleados.create');
Route::post('/empleados', [empleadoController::class, 'store'])->name('empleados.store');
//Para proveedores
Route::get('/proveedores', [proveedorController::class, 'index'])->name('proveedor.index');
Route::get('/proveedores/create', [proveedorController::class, 'create'])->name('proveedor.create');
Route::post('/proveedores', [proveedorController::class, 'store'])->name('proveedor.store');
